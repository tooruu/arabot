from .console_log import ConsoleLog
from .empty_log import EmptyLog
from .log_base import LogBase
from .log_level import LogLevel