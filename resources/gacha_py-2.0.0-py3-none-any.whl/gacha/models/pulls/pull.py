class Pull:
    def __init__(self, id: int, name: str, count: int, is_rare: bool):
        self.id = id
        self.name = name
        self.count = count
        self.is_rare = is_rare