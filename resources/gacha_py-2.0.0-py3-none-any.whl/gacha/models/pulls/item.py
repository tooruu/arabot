class Item:
    def __init__(self, id: int, name: str, rate: float):
        self.id = id
        self.name = name
        self.rate = rate